
export const appName = 'WotNot';
export const STATUS_CODE = {
  200: 'Working fine',
};

