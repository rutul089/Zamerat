import component from "./APIService";
export * from './Config'
export * from './APIService'
export API from './APIService'
export default component;
