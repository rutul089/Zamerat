import sizes from '../../../theme/sizes';
export default sizes;