import colors from '../../../theme/colors';
export default colors;