import typography from '../../../theme/typography';
export default typography;